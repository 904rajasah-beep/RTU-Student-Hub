package com.rtustudenthub

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

data class Note(val title: String, val subject: String)
data class Pyq(val title: String, val year: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RTUStudentHubApp() }
    }
}

@Composable
fun RTUStudentHubApp() {
    var selected by remember { mutableStateOf(0) }
    val tabs = listOf("Home", "Notes", "PYQ", "Results", "More")

    MaterialTheme {
        Scaffold(
            topBar = {
                TopAppBar(title = { Text("RTU Student Hub") })
            },
            bottomBar = {
                NavigationBar {
                    tabs.forEachIndexed { index, label ->
                        NavigationBarItem(
                            selected = selected == index,
                            onClick = { selected = index },
                            icon = { Text(listOf("⌂","📚","📄","📊","☰")[index]) },
                            label = { Text(label) }
                        )
                    }
                }
            }
        ) { padding ->
            Box(Modifier.padding(padding).padding(16.dp)) {
                when (selected) {
                    0 -> HomeScreen()
                    1 -> NotesScreen()
                    2 -> PyqScreen()
                    3 -> ResultsScreen()
                    4 -> MoreScreen()
                }
            }
        }
    }
}

@Composable
fun HomeScreen() {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Welcome to RTU Student Hub", style = MaterialTheme.typography.headlineSmall)
        Text("Rabindranath Tagore University • Mathematics Department")
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Today's Updates", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                Text("No new announcements yet.")
            }
        }
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Quick access", style = MaterialTheme.typography.titleMedium)
                Text("Notes • PYQs • Test Results")
            }
        }
    }
}

@Composable
fun NotesScreen() {
    val notes = listOf(
        Note("Differential Equations — Unit 1", "Mathematics"),
        Note("Thermodynamics — Introduction", "Physics"),
        Note("AEC English — Communication", "English")
    )
    Column {
        Text("Daily Notes", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(notes) { n ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text(n.title, style = MaterialTheme.typography.titleMedium)
                        Text(n.subject)
                    }
                }
            }
        }
    }
}

@Composable
fun PyqScreen() {
    val pyqs = listOf(
        Pyq("Mathematics Semester 1 PYQ", "2025"),
        Pyq("Mathematics Semester 1 PYQ", "2024"),
        Pyq("Physics Semester 1 PYQ", "2025")
    )
    Column {
        Text("Previous Year Questions", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(pyqs) { p ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text(p.title, style = MaterialTheme.typography.titleMedium)
                        Text("Year: ${p.year}")
                    }
                }
            }
        }
    }
}

@Composable
fun ResultsScreen() {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Test Results", style = MaterialTheme.typography.headlineSmall)
        Text("Sign in to view your personal test results.")
        Button(onClick = { }) { Text("Student Login") }
    }
}

@Composable
fun MoreScreen() {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("More", style = MaterialTheme.typography.headlineSmall)
        Text("Teacher/Admin login will be connected in the backend phase.")
        OutlinedButton(onClick = { }) { Text("Teacher / Admin Login") }
        OutlinedButton(onClick = { }) { Text("Student Login") }
    }
}
