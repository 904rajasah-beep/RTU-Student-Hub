# RTU Student Hub — V1

Android starter for:
- Daily notes
- Previous Year Questions
- Test results
- Announcements
- Student login
- Teacher/Admin login

## Next backend phase
Connect Firebase Authentication, Firestore, and Cloud Storage:
- Students: Google sign-in + student ID/password
- Teachers: authorized accounts
- Admins: role-based access
- Notes/PYQs: PDF storage + metadata
- Results: private per-student records
- Announcements: push notifications

Before Play Store release, configure the Firebase project, privacy policy, app icon, screenshots, release signing, and Play Console requirements.
